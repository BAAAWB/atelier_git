#include <gtk/gtk.h>

  GtkWidget *acceuil;
  GtkWidget *gestion;




struct Date1
{
int jour;
int mois;
int annee;
}Date1;




struct Date2
{
int jour;
int mois;
int annee;
}Date2;



typedef struct produit produit;
struct produit{
char id[30];
char nom[30];
char prix[30];
char date_entree[30];
char date_expiration[30];
char fournisseur[30]; 
char rangement[30];
char quantity[30];
struct Date1 date1;
struct Date2 date2;
};

int i,j,k;
void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_Ajouterproduit_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifierproduit_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimerproduit_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercherproduit_clicked             (GtkButton       *button,
                                        gpointer         user_data);
void
on_treeview_capt_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview_alarm_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajouter_capt_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifier_capt_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimer_capt_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_parametre_capt_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Ajout_ok_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_ajout_clicked                (GtkWidget       *button,
                                        gpointer         user_data);


void
on_modif_ok_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_modif_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_supprim_ok_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);


void
on_retour_supp_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview_param_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajout_param_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_param_ok_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_param_clicked                (GtkWidget       *button,
                                        gpointer         user_data);


void
on_temperature_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_humidite_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_alarmantes_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

/*void
on_defec_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);*/

void
on_capt_clicked                        (GtkButton       *button,
                                        gpointer         user_data);
