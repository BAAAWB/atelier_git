#include <gtk/gtk.h>
void ajouter_produit( produit c);
int exist_produit(char*id);
void supprimer_produit(char*id);
